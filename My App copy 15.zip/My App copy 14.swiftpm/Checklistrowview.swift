import SwiftUI

struct ChecklistRowView: View {
    let item: ChecklistItem
    
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(item.isChecked ? Color(red: 0.1, green: 0.55, blue: 0.1) : Color.clear)
                    .frame(width: 24, height: 24)
                Circle()
                    .strokeBorder(Color.black, lineWidth: 1.5)
                    .frame(width: 24, height: 24)
                if item.isChecked {
                    Image(systemName: "checkmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(.white)
                }
            }
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: item.isChecked)
            
            Text(item.name)
                .font(.body)
                .foregroundStyle(item.isChecked ? .secondary : .primary)
                .strikethrough(item.isChecked, color: .secondary)
                .animation(.easeInOut(duration: 0.2), value: item.isChecked)
            
            Spacer()
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
    }
}
