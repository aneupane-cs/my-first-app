import SwiftUI

struct CongratsView: View {
    let streak: Int
    @Environment(\.dismiss) private var dismiss
    @State private var scaleEffect = 0.5
    @State private var opacity = 0.0
    
    private let messages = [
        "You're crushing it! 🎉",
        "Morning: conquered! ☀️",
        "Look at you go! 🌟",
        "Nailed it! 🙌",
        "You're on fire! 🔥"
    ]
    
    private var randomMessage: String {
        messages.randomElement() ?? messages[0]
    }
    
    var body: some View {
        VStack(spacing: 28) {
            Spacer()
            
            Text("🏆")
                .font(.system(size: 80))
                .scaleEffect(scaleEffect)
                .opacity(opacity)
            
            VStack(spacing: 8) {
                Text("Congratulations!")
                    .font(.title)
                    .fontWeight(.bold)
                
                Text(randomMessage)
                    .font(.title3)
                    .foregroundStyle(.secondary)
            }
            .opacity(opacity)
            
            if streak > 0 {
                HStack(spacing: 6) {
                    Image(systemName: "flame.fill")
                    Text("\(streak) day streak!")
                        .fontWeight(.semibold)
                }
                .font(.subheadline)
                .foregroundStyle(.white)
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(Color(red: 0.85, green: 0.4, blue: 0.0))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.black, lineWidth: 1.5))
                .opacity(opacity)
            }
            
            Text("Your morning routine is complete.\nHave a great day!")
                .font(.body)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .opacity(opacity)
            
            Spacer()
            
            Button {
                dismiss()
            } label: {
                Text("Let's go!")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(red: 0.1, green: 0.55, blue: 0.1))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.black, lineWidth: 1.5))
            }
            .padding(.horizontal, 32)
            .padding(.bottom, 32)
            .opacity(opacity)
        }
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                scaleEffect = 1.0
                opacity = 1.0
            }
        }
    }
}
