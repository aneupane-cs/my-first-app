import SwiftUI

struct ContentView: View {
    @EnvironmentObject var vm: ChecklistViewModel
    @State private var showingSettings = false
    @State private var showingCongrats = false
    @State private var wasAllDone = false
    
    private var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        if hour < 12 { return "Good morning" }
        if hour < 17 { return "Good afternoon" }
        return "Good evening"
    }
    
    private var dateString: String {
        let f = DateFormatter()
        f.dateFormat = "EEEE, MMM d"
        return f.string(from: Date())
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                headerView
                progressSection
                itemList
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingSettings = true
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .sheet(isPresented: $showingSettings) {
                SettingsView()
                    .environmentObject(vm)
            }
            .onChange(of: vm.allDone) {
                if vm.allDone && !wasAllDone {
                    showingCongrats = true
                }
                wasAllDone = vm.allDone
            }
            .sheet(isPresented: $showingCongrats) {
                CongratsView(streak: vm.streak)
            }
        }
    }
    
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(dateString)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(greeting)
                        .font(.title2)
                        .fontWeight(.semibold)
                }
                Spacer()
                if vm.streak > 0 {
                    streakBadge
                }
            }
        }
        .padding(.horizontal)
        .padding(.top, 12)
        .padding(.bottom, 8)
    }
    
    private var streakBadge: some View {
        HStack(spacing: 4) {
            Image(systemName: "flame.fill")
                .font(.system(size: 12))
            Text("\(vm.streak) day\(vm.streak == 1 ? "" : "s")")
                .font(.caption)
                .fontWeight(.medium)
        }
        .foregroundStyle(Color(red: 0.85, green: 0.4, blue: 0.0))
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(Color(red: 0.85, green: 0.4, blue: 0.0).opacity(0.15))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.black, lineWidth: 1.0))
    }
    
    private var progressSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            ProgressView(value: vm.progress)
                .tint(vm.allDone ? Color(red: 0.1, green: 0.55, blue: 0.1) : Color(red: 0.15, green: 0.35, blue: 0.75))
                .animation(.easeInOut, value: vm.progress)
            
            Text(vm.allDone ? "All done! Great morning." : "\(vm.checkedCount) of \(vm.totalCount) done")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
    }
    
    private var itemList: some View {
        List {
            ForEach(vm.items) { item in
                Button {
                    vm.toggleByID(item.id)
                } label: {
                    ChecklistRowView(item: item)
                }
                .buttonStyle(.plain)
            }
            .onDelete(perform: vm.deleteItems)
            .onMove(perform: vm.moveItems)
        }
        .listStyle(.plain)
    }
}
