import Foundation
import Combine
import UserNotifications

class ChecklistViewModel: ObservableObject {
    @Published var items: [ChecklistItem] = []
    @Published var streak: Int = 0
    @Published var reminderTime: Date = Calendar.current.date(from: DateComponents(hour: 7, minute: 0)) ?? Date()
    @Published var reminderEnabled: Bool = false
    
    private let itemsKey = "checklist_items"
    private let streakKey = "checklist_streak"
    private let lastCompletedKey = "checklist_last_completed"
    private let reminderTimeKey = "checklist_reminder_time"
    private let reminderEnabledKey = "checklist_reminder_enabled"
    
    init() {
        loadItems()
        loadStreak()
        loadReminderSettings()
        if items.isEmpty {
            items = [
                ChecklistItem(name: "Make coffee"),
                ChecklistItem(name: "Take vitamins"),
                ChecklistItem(name: "Check calendar"),
                ChecklistItem(name: "Pack bag"),
                ChecklistItem(name: "Grab keys")
            ]
            saveItems()
        }
    }
    
    var checkedCount: Int { items.filter { $0.isChecked }.count }
    var totalCount: Int { items.count }
    var progress: Double { totalCount == 0 ? 0 : Double(checkedCount) / Double(totalCount) }
    var allDone: Bool { totalCount > 0 && checkedCount == totalCount }
    
    func toggle(_ item: ChecklistItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        let nowChecked = !items[index].isChecked
        items[index].isChecked = nowChecked
        if nowChecked {
            UserDefaults.standard.set(Date(), forKey: items[index].checkedKey)
        } else {
            UserDefaults.standard.removeObject(forKey: items[index].checkedKey)
        }
        let checkedCount = items.filter { $0.isChecked }.count
        if checkedCount == items.count { handleCompletion() }
    }
    
    func addItem(name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        items.append(ChecklistItem(name: trimmed))
        saveItems()
    }
    
    func deleteItems(at offsets: IndexSet) {
        offsets.forEach { UserDefaults.standard.removeObject(forKey: items[$0].checkedKey) }
        items.remove(atOffsets: offsets)
        saveItems()
    }
    
    func moveItems(from source: IndexSet, to destination: Int) {
        items.move(fromOffsets: source, toOffset: destination)
        saveItems()
    }
    
    func setReminder(enabled: Bool, time: Date) {
        reminderEnabled = enabled
        reminderTime = time
        UserDefaults.standard.set(enabled, forKey: reminderEnabledKey)
        UserDefaults.standard.set(time, forKey: reminderTimeKey)
        scheduleNotification()
    }
    
    private func handleCompletion() {
        let today = Calendar.current.startOfDay(for: Date())
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: today)!
        
        if let lastCompleted = UserDefaults.standard.object(forKey: lastCompletedKey) as? Date {
            let lastDay = Calendar.current.startOfDay(for: lastCompleted)
            if lastDay == yesterday {
                streak += 1
            } else if lastDay < yesterday {
                streak = 1
            }
        } else {
            streak = 1
        }
        
        UserDefaults.standard.set(Date(), forKey: lastCompletedKey)
        UserDefaults.standard.set(streak, forKey: streakKey)
    }
    
    private func scheduleNotification() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["morning_reminder"])
        guard reminderEnabled else { return }
        
        let content = UNMutableNotificationContent()
        content.title = "Good morning"
        content.body = "Time to run through your morning checklist."
        content.sound = .default
        
        let comps = Calendar.current.dateComponents([.hour, .minute], from: reminderTime)
        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: true)
        let request = UNNotificationRequest(identifier: "morning_reminder", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }
    
    private func saveItems() {
        if let encoded = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(encoded, forKey: itemsKey)
        }
    }
    
    private func loadItems() {
        guard let data = UserDefaults.standard.data(forKey: itemsKey),
              var decoded = try? JSONDecoder().decode([ChecklistItem].self, from: data) else { return }
        for i in decoded.indices {
            if let lastChecked = UserDefaults.standard.object(forKey: decoded[i].checkedKey) as? Date {
                decoded[i].isChecked = Calendar.current.isDateInToday(lastChecked)
                if !decoded[i].isChecked {
                    UserDefaults.standard.removeObject(forKey: decoded[i].checkedKey)
                }
            } else {
                decoded[i].isChecked = false
            }
        }
        items = decoded
    }
    
    private func loadStreak() {
        streak = UserDefaults.standard.integer(forKey: streakKey)
        if let lastCompleted = UserDefaults.standard.object(forKey: lastCompletedKey) as? Date {
            let lastDay = Calendar.current.startOfDay(for: lastCompleted)
            let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: Calendar.current.startOfDay(for: Date()))!
            if lastDay < yesterday {
                streak = 0
                UserDefaults.standard.set(0, forKey: streakKey)
            }
        }
    }
    
    private func loadReminderSettings() {
        reminderEnabled = UserDefaults.standard.bool(forKey: reminderEnabledKey)
        if let saved = UserDefaults.standard.object(forKey: reminderTimeKey) as? Date {
            reminderTime = saved
        }
    }
}
