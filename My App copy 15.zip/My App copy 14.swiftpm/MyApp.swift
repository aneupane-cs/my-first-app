import SwiftUI
import UserNotifications

@main
struct MyApp: App {
    @StateObject private var viewModel = ChecklistViewModel()
    
    init() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
