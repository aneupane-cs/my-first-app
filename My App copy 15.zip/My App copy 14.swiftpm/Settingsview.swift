import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var vm: ChecklistViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var newItemName = ""
    @State private var reminderEnabled: Bool = false
    @State private var reminderTime: Date = Date()
    
    var body: some View {
        NavigationStack {
            List {
                itemsSection
                addItemSection
                reminderSection
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton()
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.medium)
                }
            }
            .onAppear {
                reminderEnabled = vm.reminderEnabled
                reminderTime = vm.reminderTime
            }
        }
    }
    
    private var itemsSection: some View {
        Section("Checklist items") {
            ForEach(vm.items) { item in
                HStack {
                    Image(systemName: "line.3.horizontal")
                        .foregroundStyle(.tertiary)
                        .font(.system(size: 13))
                    Text(item.name)
                }
            }
            .onDelete(perform: vm.deleteItems)
            .onMove(perform: vm.moveItems)
        }
    }
    
    private var addItemSection: some View {
        Section {
            HStack {
                TextField("New item...", text: $newItemName)
                    .submitLabel(.done)
                    .onSubmit(addItem)
                if !newItemName.trimmingCharacters(in: .whitespaces).isEmpty {
                    Button(action: addItem) {
                        Image(systemName: "plus.circle.fill")
                            .foregroundStyle(.blue)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
    
    private var reminderSection: some View {
        Section("Daily reminder") {
            Toggle("Remind me each morning", isOn: $reminderEnabled)
                .onChange(of: reminderEnabled) {
                    vm.setReminder(enabled: reminderEnabled, time: reminderTime)
                }
            DatePicker("Reminder time", selection: $reminderTime, displayedComponents: .hourAndMinute)
                .onChange(of: reminderTime) {
                    vm.setReminder(enabled: reminderEnabled, time: reminderTime)
                }
                .foregroundStyle(reminderEnabled ? .primary : .secondary)
        }
    }
    
    private func addItem() {
        vm.addItem(name: newItemName)
        newItemName = ""
    }
}
