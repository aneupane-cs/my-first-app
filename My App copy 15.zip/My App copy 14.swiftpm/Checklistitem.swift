import Foundation

struct ChecklistItem: Identifiable, Codable {
    let id: UUID
    var name: String
    var isChecked: Bool
    
    init(id: UUID = UUID(), name: String, isChecked: Bool = false) {
        self.id = id
        self.name = name
        self.isChecked = isChecked
    }
    
    var checkedKey: String { "checked_\(id.uuidString)" }
}
